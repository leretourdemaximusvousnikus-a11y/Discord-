const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, PermissionFlagsBits, MessageFlags, StringSelectMenuBuilder } = require('discord.js');

const SALON_VERIF_ID = "1536157941562998886"; // #se-vérifier - change si besoin

const setupReglementCommand = {
    data: new SlashCommandBuilder().setName('setup_reglement').setDescription('Envoie le règlement corrigé avec salon').setDefaultMemberPermissions(PermissionFlagsBits.Administrator),
    async execute(interaction) {
        const embed = new EmbedBuilder()
           .setTitle("⚖️ │ RÈGLEMENT GÉNÉRAL & SÉCURITÉ")
           .setColor(0xFF0000)
           .setDescription(
                "────────────────────────────────────────────────\n\n" +
                "Bienvenue sur **Empire Nocturne**.\n\n" +
                "Pour garantir la sécurité de tous, merci de lire et respecter le règlement.\n\n" +
                "**Serveur 18+ strict | Tolérance zéro sur le non-consenti, mineurs et doxxing.**\n\n" +
                "👉 Clique sur les boutons ci-dessous pour afficher les détails.\n\n" +
                "────────────────────────────────────────────────\n" +
                "En accédant au serveur, tu acceptes les T.O.S Discord.\n\n" +
                `👉 Une fois lu, va dans <#${SALON_VERIF_ID}> pour te vérifier.`
            );
        const row = new ActionRowBuilder().addComponents(
            new ButtonBuilder().setCustomId('btn_voir_reglement_complet').setLabel('Règlement complet').setEmoji('📜').setStyle(ButtonStyle.Danger),
            new ButtonBuilder().setCustomId('btn_voir_sanctions').setLabel('Sanctions & Sécurité').setEmoji('🛡️').setStyle(ButtonStyle.Secondary)
        );
        await interaction.channel.send({ embeds: [embed], components: [row] });
        await interaction.reply({ content: "✅ Règlement avec salon en bas envoyé!", flags: MessageFlags.Ephemeral });
    }
};

const setupVerificationCommand = {
    data: new SlashCommandBuilder().setName('setup_verification').setDescription('Setup verif 18+').setDefaultMemberPermissions(PermissionFlagsBits.Administrator),
    async execute(interaction) {
        const embed = new EmbedBuilder()
           .setTitle("🔞 │ VÉRIFICATIONS 18+")
           .setColor(0x2B2D31)
           .setDescription("**Vérifie si t'es majeur**\n\nTu dois certifier être majeur pour accéder au reste du serveur.\n\n👉 **Clique sur le bouton Membre +18 pour débloquer le rôle**");
        const row = new ActionRowBuilder().addComponents(new ButtonBuilder().setCustomId('btn_verif_18').setLabel('Membre +18').setEmoji('🔞').setStyle(ButtonStyle.Danger));
        await interaction.channel.send({ embeds: [embed], components: [row] });
        await interaction.reply({ content: "✅ Verif envoyée!", flags: MessageFlags.Ephemeral });
    }
};

const setupModoCommand = {
    data: new SlashCommandBuilder().setName('setup_modo').setDescription('Panel modo').setDefaultMemberPermissions(PermissionFlagsBits.Administrator),
    async execute(interaction) {
        const embed = new EmbedBuilder().setTitle("🛡️ │ PANEL MODÉRATION").setColor(0x2B2D31).setDescription("BAN / KICK / MUTE / WARN");
        const row = new ActionRowBuilder().addComponents(
            new ButtonBuilder().setCustomId('modo_ban').setLabel('BAN').setEmoji('🔨').setStyle(ButtonStyle.Danger),
            new ButtonBuilder().setCustomId('modo_kick').setLabel('KICK').setEmoji('👢').setStyle(ButtonStyle.Secondary),
            new ButtonBuilder().setCustomId('modo_mute').setLabel('MUTE').setEmoji('🔇').setStyle(ButtonStyle.Secondary),
            new ButtonBuilder().setCustomId('modo_warn').setLabel('WARN').setEmoji('⚠️').setStyle(ButtonStyle.Secondary)
        );
        await interaction.channel.send({ embeds: [embed], components: [row] });
        await interaction.reply({ content: "✅ Panel modo envoyé!", flags: MessageFlags.Ephemeral });
    }
};

const setupIdPanelCommand = {
    data: new SlashCommandBuilder().setName('setup_id_panel').setDescription('Panel ID 1 membre = 1 ID copiable').setDefaultMemberPermissions(PermissionFlagsBits.Administrator),
    async execute(interaction) {
        await interaction.deferReply({ flags: MessageFlags.Ephemeral });
        await interaction.guild.members.fetch();
        await interaction.guild.roles.fetch();
        const membres = interaction.guild.members.cache.filter(m=>!m.user.bot).sort((a,b)=>a.user.username.localeCompare(b.user.username));
        const bots = interaction.guild.members.cache.filter(m=>m.user.bot).sort((a,b)=>a.user.username.localeCompare(b.user.username));
        const roles = interaction.guild.roles.cache.filter(r=>r.name!=='@everyone' && !r.managed).sort((a,b)=>b.position-a.position);

        const embed = new EmbedBuilder()
            .setTitle("🆔 │ PANEL IDs COPIABLES")
            .setColor(0x5865F2)
            .setDescription("**Choisis un membre, bot ou rôle pour avoir son ID copiable en 1 clic.**\n\n👥 Membres = vrais gens\n🤖 Bots = bots\n🎭 Rôles = rôles");

        const selectMembres = new StringSelectMenuBuilder()
            .setCustomId('select_id_membre')
            .setPlaceholder(`👥 MEMBRES (${membres.size})`)
            .addOptions(membres.first(25).map(m=>({ label: m.user.username.slice(0,100), description: `ID: ${m.id}`, value: m.id })));
        const selectBots = new StringSelectMenuBuilder()
            .setCustomId('select_id_bot')
            .setPlaceholder(`🤖 BOTS (${bots.size})`)
            .addOptions(bots.first(25).map(m=>({ label: m.user.username.slice(0,100), description: `ID: ${m.id}`, value: m.id })));
        const selectRoles = new StringSelectMenuBuilder()
            .setCustomId('select_id_role')
            .setPlaceholder(`🎭 RÔLES (${roles.size})`)
            .addOptions(roles.first(25).map(r=>({ label: r.name.slice(0,100), description: `ID: ${r.id}`, value: r.id })));

        const row1 = new ActionRowBuilder().addComponents(selectMembres);
        const row2 = new ActionRowBuilder().addComponents(selectBots);
        const row3 = new ActionRowBuilder().addComponents(selectRoles);

        const components = [row1, row2, row3];
        if (membres.size > 25) {
            const selectMembres2 = new StringSelectMenuBuilder()
                .setCustomId('select_id_membre2')
                .setPlaceholder(`👥 Membres suite 26-${Math.min(50,membres.size)}`)
                .addOptions(membres.toJSON().slice(25,50).map(m=>({ label: m.user.username.slice(0,100), description: `ID: ${m.id}`, value: m.id })));
            components.push(new ActionRowBuilder().addComponents(selectMembres2));
        }

        await interaction.channel.send({ embeds: [embed], components });
        await interaction.editReply({ content: "✅ Panel ID envoyé!" });
    }
};

const getIdRoleCommand = {
    data: new SlashCommandBuilder().setName('getidrole').setDescription('Liste rôles').setDefaultMemberPermissions(PermissionFlagsBits.Administrator),
    async execute(interaction) {
        await interaction.deferReply({ flags: MessageFlags.Ephemeral });
        const roles = interaction.guild.roles.cache.filter(r => r.name!== '@everyone').sort((a,b)=>b.position-a.position).map(r => `**${r.name}** : \`${r.id}\``);
        const embed = new EmbedBuilder().setTitle("🆔 │ RÔLES").setDescription(roles.join('\n').slice(0,4000)).setColor(0x2B2D31);
        return interaction.editReply({ embeds: [embed] });
    }
};

module.exports = { setupReglementCommand, setupVerificationCommand, setupModoCommand, setupIdPanelCommand, getIdRoleCommand };
                
