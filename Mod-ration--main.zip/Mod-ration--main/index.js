const express = require('express');
const { Client, GatewayIntentBits, Collection, REST, Routes, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ModalBuilder, TextInputBuilder, TextInputStyle, ButtonStyle, MessageFlags } = require('discord.js');
const { setupReglementCommand, setupVerificationCommand, setupModoCommand, setupIdPanelCommand, getIdRoleCommand } = require('./commands.js');

const app = express();
app.get('/', (req,res)=> res.send("Bot FIX SALON + SANCTIONS BLOC ok"));
app.listen(process.env.PORT || 10000, ()=> console.log('[HTTP] OK'));

const GUILD_ID = "1536146991170461739";
const ROLE_VERIF_ID = "1536160558229749870";

const client = new Client({ intents: [GatewayIntentBits.Guilds, GatewayIntentBits.GuildMembers, GatewayIntentBits.GuildMessages, GatewayIntentBits.MessageContent] });

client.commands = new Collection();
[setupReglementCommand, setupVerificationCommand, setupModoCommand, setupIdPanelCommand, getIdRoleCommand].forEach(c => client.commands.set(c.data.name, c));

client.on('interactionCreate', async interaction => {
    // ===== REGLEMENT COMPLET - AVEC SALON EN BAS =====
    if (interaction.customId === 'btn_voir_reglement_complet') {
        const e = new EmbedBuilder()
            .setTitle("📜 │ RÈGLEMENT COMPLET - EMPIRE NOCTURNE")
            .setColor(0xFF0000)
            .setDescription(
                "────────────────────────────────────────────────\n\n" +
                "En accédant à **Empire Nocturne**, vous acceptez ces règles et les T.O.S Discord.\n\n" +
                "**1⃣ │ ACCÈS 18+ OBLIGATOIRE**\n" +
                "• Serveur réservé aux majeurs uniquement (18+).\n" +
                "• Tu certifies sur l'honneur être majeur.\n" +
                "• Tout comportement suspect = exclusion immédiate et signalement.\n\n" +
                "**2⃣ │ RESPECT & LÉGALITÉ**\n" +
                "• Interdit : contenu impliquant des mineurs, contenu non-consenti, leaks, revenge porn, harcèlement, menaces.\n" +
                "• Tolérance zéro absolue.\n\n" +
                "**3⃣ │ SÉCURITÉ**\n" +
                "• Interdit : doxxing, spam DM pour pub, liens douteux / .exe / phishing / virus.\n" +
                "• Merci de signaler tout problème au staff.\n\n" +
                "**4⃣ │ BONNE ENTENTE**\n" +
                "• Reste dans le thème des salons.\n" +
                "• Pas de spam, pas de pub sans autorisation.\n\n" +
                "────────────────────────────────────────────────\n" +
                "Le staff se réserve le droit de sanctionner :\n" +
                "⚠️ **Avertissement → Mute → Kick → Ban**\n\n" +
                "👉 Une fois lu, va te vérifier dans le salon vérification."
            );
        return interaction.reply({ embeds: [e], flags: MessageFlags.Ephemeral });
    }

    // ===== SANCTIONS - VERSION BLOC CODE COMME TU AIMES (PHOTO 1) =====
    if (interaction.customId === 'btn_voir_sanctions') {
        const e = new EmbedBuilder()
            .setTitle("🛡️ │ SANCTIONS & SÉCURITÉ")
            .setColor(0x2B2D31)
            .setDescription(
                "**Tolérance zéro → Ban + Signalement :**\n" +
                "• Mineurs / CSAM / IA mineur\n" +
                "• Non-consenti / leaks / revenge porn\n" +
                "• Doxxing / phishing / .exe / virus\n" +
                "• Apologie violence extrême / haine\n\n" +
                "**Progressif :**\n" +
                "```\n" +
                "Hors-sujet / Spam léger       -> WARN\n" +
                "Provoc / Irrespect            -> MUTE 1h-12h\n" +
                "Spam / Pub DM / Récidive      -> MUTE 24h / KICK\n" +
                "Toxicité / Troll              -> KICK\n" +
                "Retour après kick + refaute   -> BAN\n" +
                "```\n\n" +
                "⚠️ **Barème : WARN → MUTE → KICK → BAN**"
            );
        return interaction.reply({ embeds: [e], flags: MessageFlags.Ephemeral });
    }

    if (interaction.customId === 'btn_verif_18') {
        await interaction.member.roles.add(ROLE_VERIF_ID).catch(()=>{});
        return interaction.reply({ content: `✅ <@&${ROLE_VERIF_ID}> ajouté !`, flags: MessageFlags.Ephemeral });
    }

    // SELECT ID
    if (interaction.isStringSelectMenu() && interaction.customId.startsWith('select_id_')) {
        const id = interaction.values[0];
        let name = id;
        try {
            if (interaction.customId.includes('role')) {
                const r = interaction.guild.roles.cache.get(id);
                name = r ? r.name : id;
            } else {
                const m = await interaction.guild.members.fetch(id).catch(()=>null);
                name = m ? m.user.username : id;
            }
        } catch {}
        const type = interaction.customId.includes('role') ? 'Rôle' : interaction.customId.includes('bot') ? 'Bot' : 'Membre';
        const embed = new EmbedBuilder()
            .setTitle(`🆔 │ ${type} : ${name}`)
            .setColor(0x2B2D31)
            .setDescription(`**${type} : ${name}**\n\n**ID copiable :**\n\`\`\`\n${id}\n\`\`\`\nReste appuyé pour copier.`);
        return interaction.reply({ embeds: [embed], flags: MessageFlags.Ephemeral });
    }

    if (['modo_ban','modo_kick','modo_mute','modo_warn'].includes(interaction.customId)) {
        const isMute = interaction.customId === 'modo_mute';
        if(isMute){
            const m = new ModalBuilder().setCustomId('modal_mute').setTitle('🔇 Mute');
            m.addComponents(
                new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('userId').setLabel('ID').setStyle(TextInputStyle.Short).setRequired(true)),
                new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('duration').setLabel('Durée min').setStyle(TextInputStyle.Short).setRequired(true).setValue('60')),
                new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('reason').setLabel('Raison').setStyle(TextInputStyle.Paragraph).setRequired(true))
            );
            return interaction.showModal(m);
        }
        const modal = new ModalBuilder().setCustomId(`modal_${interaction.customId.split('_')[1]}`).setTitle(interaction.customId.toUpperCase());
        modal.addComponents(
            new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('userId').setLabel('ID').setStyle(TextInputStyle.Short).setRequired(true)),
            new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('reason').setLabel('Raison').setStyle(TextInputStyle.Paragraph).setRequired(true))
        );
        return interaction.showModal(modal);
    }
    if (interaction.isModalSubmit() && interaction.customId.startsWith('modal_')) {
        const userId = interaction.fields.getTextInputValue('userId');
        const reason = interaction.fields.getTextInputValue('reason') || 'Aucune';
        try {
            if (interaction.customId === 'modal_ban') {
                await interaction.guild.members.ban(userId, { reason }).catch(async()=>{ const mm = await interaction.guild.members.fetch(userId).catch(()=>null); if(mm) await mm.ban({ reason }); });
                return interaction.reply({ content: `🔨 <@${userId}> BAN: ${reason}`, flags: MessageFlags.Ephemeral });
            }
            if (interaction.customId === 'modal_kick') {
                const mm = await interaction.guild.members.fetch(userId);
                await mm.kick(reason);
                return interaction.reply({ content: `👢 <@${userId}> KICK: ${reason}`, flags: MessageFlags.Ephemeral });
            }
            if (interaction.customId === 'modal_mute') {
                const dur = parseInt(interaction.fields.getTextInputValue('duration'));
                const mm = await interaction.guild.members.fetch(userId);
                await mm.timeout(dur*60*1000, reason);
                return interaction.reply({ content: `🔇 <@${userId}> MUTE ${dur}min: ${reason}`, flags: MessageFlags.Ephemeral });
            }
            if (interaction.customId === 'modal_warn') {
                const t = await interaction.guild.members.fetch(userId).catch(()=>null);
                if(t) await t.send(`⚠️ WARN sur ${interaction.guild.name}: ${reason}`).catch(()=>{});
                return interaction.reply({ content: `⚠️ <@${userId}> WARN: ${reason}`, flags: MessageFlags.Ephemeral });
            }
        } catch(err){ return interaction.reply({ content: `❌ ${err.message}`, flags: MessageFlags.Ephemeral }); }
    }

    if (!interaction.isChatInputCommand()) return;
    const cmd = client.commands.get(interaction.commandName);
    if(cmd) await cmd.execute(interaction);
});

client.once('clientReady', async () => {
    console.log(`[FIX SALON+SANCTIONS] ${client.user.tag}`);
    const rest = new REST({ version: '10' }).setToken(process.env.DISCORD_TOKEN);
    const body = Array.from(client.commands.values()).map(c=>c.data.toJSON());
    await rest.put(Routes.applicationGuildCommands(client.user.id, GUILD_ID), { body });
});
client.login(process.env.DISCORD_TOKEN);
                
